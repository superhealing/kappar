# Contributing to Kappar

👍🎉 First off, thanks for taking the time to contribute! 🎉👍

- Please target the develop branch with PRs
- That's all for now 😄